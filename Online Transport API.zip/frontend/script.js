// const BASEURL = 'https://vizrapi.bestworks.online';
const BASEURL = 'http://127.0.0.1:5000';

// Utils
function get(selector, root = document) {
  return root.querySelector(selector);
}

function formatDate(date) {
  const h = "0" + date.getHours();
  const m = "0" + date.getMinutes();

  return `${h.slice(-2)}:${m.slice(-2)}`;
}

function random(min, max) {
  return Math.floor(Math.random() * (max - min) + min);
}
// End of Utils

const msgerForm = get(".msger-inputarea");
const msgerInput = get(".msger-input");
const msgerChat = get(".msger-chat");


// Icons made by Freepik from www.flaticon.com
const BOT_IMG = "../bot.png";
const PERSON_IMG = "../ava1-bg.webp";
const BOT_NAME = "Bot";
const PERSON_NAME = "You";
var vizr_topic = '';
jQuery(document).ready(function ($) {

  $('.quick_information').click(function () {
    $('.msger').slideToggle(500);
  });

  appendMessage(BOT_NAME, BOT_IMG, 'left', 'Hello! I am online transport assistant. How can I assist you today?');
});

// handle submit when user clicks on "Send" button or hits "Enter"
msgerForm.addEventListener("submit", event => {
  event.preventDefault();

  const msgText = msgerInput.value;
  if (!msgText)
    return;

  appendMessage(PERSON_NAME, PERSON_IMG, "right", msgText);
  msgerInput.value = "";

  botResponse(msgText);
});

// append message to chat box
function appendMessage(name, img, side, text) {

  const msgHTML = `
    <div class="msg ${side}-msg">
      <div class="msg-img" style="background-image: url(${img})"></div>

      <div class="msg-bubble">
        <div class="msg-info">
          <div class="msg-info-name">${name}</div>
          <div class="msg-info-time">${formatDate(new Date())}</div>
        </div>

        <pre class="msg-text">${text}</pre>
      </div>
    </div>
  `;

  msgerChat.insertAdjacentHTML("beforeend", msgHTML);
  msgerChat.scrollTop += 500;
}

// fetch bot response
function botResponse(msgText) {

  // Add typing loader to the chat
  appendTypingLoader();

  const url = BASEURL + '/ask';

  const inputData = {
    question: msgText
  };

  fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(inputData),
  }).then((response) => {
    if (!response.ok) {
      throw new Error('HTTP POST request failed with status ' + response.status);
    }
    return response.json();
  }).then((data) => {
    console.log(data);
    removeTypingLoader();
    appendMessage(BOT_NAME, BOT_IMG, "left", data?.answer);
    rgfbMakeTextH3();
    rgfbMakeTextBold();
    rgfbMakeTextStrong();
  }).catch((error) => {
    removeTypingLoader();
    console.error('Error:', error);
  });

}

// Append typing loader to the chat
function appendTypingLoader() {
  const loaderHTML = `
    <div class="msg left-msg">
      <div class="msg-img" style="background-image: url(../bot.png)"></div>
      <div class="msg-bubble">
        <div class="msg-info">
          <div class="msg-info-name">VIZR</div>
          <div class="msg-info-time">${formatDate(new Date())}</div>
        </div>
        <div class="typing-loader">
          <span class="loader-dot"></span>
          <span class="loader-dot"></span>
          <span class="loader-dot"></span>
        </div>
      </div>
    </div>
  `;
  msgerChat.insertAdjacentHTML("beforeend", loaderHTML);
  msgerChat.scrollTop += 500;
}

// Remove the typing loader from the chat
function removeTypingLoader() {
  const typingLoader = document.querySelector(".left-msg:last-child");
  if (typingLoader) {
    typingLoader.remove();
  }
}

function rgfbMakeTextBold() {
  var containers = document.getElementsByClassName('msg-text');
  for (var i = 0; i < containers.length; i++) {
    containers[i].innerHTML = containers[i].innerHTML.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  }
}

function rgfbMakeTextH3() {
  var containers = document.getElementsByClassName('msg-text');
  for (var i = 0; i < containers.length; i++) {
    containers[i].innerHTML = containers[i].innerHTML.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  }
}

function rgfbMakeTextStrong() {
  var containers = document.getElementsByClassName('msg-text');
  for (var i = 0; i < containers.length; i++) {
    containers[i].innerHTML = containers[i].innerHTML.replace(/\*(.*?)\*/g, '<strong>$1</strong>');
  }
}
