import os
import requests

from flask import Flask, request, jsonify
from flask_cors import CORS

from langchain_openai import ChatOpenAI
from langchain.agents import tool
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.agents.format_scratchpad.openai_tools import (
    format_to_openai_tool_messages,
)
from langchain.agents.output_parsers.openai_tools import OpenAIToolsAgentOutputParser
from langchain.agents import AgentExecutor

app = Flask(__name__)
CORS(app)

os.environ['OPENAI_API_KEY'] = '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'


llm = ChatOpenAI(model="gpt-4o", temperature=0)

@tool
def get_train_schedule(location):
    """Look up information about transport"""
    url = "https://api.onlinetransport.co.za/v1/online-train-service/directions/train-schedule/"
    
    params = {
        "plat": -33.9362636,
        "plon": 18.405024,
        "dlat": -33.9064726,
        "dlon": 18.6274078,
        "timing": "20:14",
        "days": 2,
        "options": 1,
        "provider": "Metro",
        "apiKey": "eb38d7bc-e510-11ee-80e7-3d055a162a32"
    }
    
    response = requests.get(url, params=params)
    
    if response.status_code == 200:
        return response.json()
    else:
        return {"error": f"Request failed with status code {response.status_code}"}

tools = [get_train_schedule]

prompt = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are very powerful assistant, but don't know current transport information.",
        ),
        ("user", "{input}"),
        MessagesPlaceholder(variable_name="agent_scratchpad"),
    ]
)

llm_with_tools = llm.bind_tools(tools)

agent = (
    {
        "input": lambda x: x["input"],
        "agent_scratchpad": lambda x: format_to_openai_tool_messages(
            x["intermediate_steps"]
        ),
    }
    | prompt
    | llm_with_tools
    | OpenAIToolsAgentOutputParser()
)


agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

@app.route('/ask', methods=['POST'])
def ask_question():
    data = request.get_json()

    if 'question' not in data:
        return jsonify({'error': 'Missing question parameter'}), 400

    question = data['question']

    answer = agent_executor.invoke({"input": question})

    response = {
        "question": question,
        "answer": answer['output']
    }

    return jsonify(response), 200


if __name__ == '__main__':
    app.run(debug=True)